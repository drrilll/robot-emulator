There are a lot of pictures, I hope I remembered them all. There is no picture of just the environment, I didn't notice that until too late. But there are plenty of others that show it.

Most of them have terrible readings. Originally I edited out the too high and too low before it went to the trace file, but I guess I disabled that at some point. The BorderMap readings in particular are just awful (except for ir6). In the end I tried a 45ish degree angle towards the wall, hoping to get a few valid readings, but I wind up discarding them all except for ir6 for the best map.

Also for the best map I used the robot shape on the colour version, and leave it out for the black and white. There are a couple of features there. I found that there was a better map using Gaussian distance only, as the Dirrs sensor spread out more and gave a nicer map, but the assignment called for Full Gaussian.

